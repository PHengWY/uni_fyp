
Barrels (Mage City Arcanos remix)

Description:
  Barrels reworked for Stendhal from Mage City Arcanos tileset.
  Also includes some tiles by isaiah658.

Tileset details:
  - Designed for use with 32x32 tiled maps.
  - Orientation: orthogonal
  - PNG images optimized with indexed color (smaller files).
  - GIMP source files (.xcf) use RGB color.

Licensing:
  - Creative Commons Zero (CC0)

Attribution (not required):
  Hyptosis, isaiah658, Jordan Irwin (AntumDeluge)

Links:
  - Stendhal: https://stendhalgame.org/
  - OpenGameArt.org submission: https://opengameart.org/node/79172
  - See also: sources.md
