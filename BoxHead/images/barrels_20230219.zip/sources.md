## Barrels Sources

![Preview](contents.png)

[OpenGameArt.org Submission](https://opengameart.org/node/79172)


Barrels by [Hyptosis](https://opengameart.org/user/2937), reworked by [Jordan Irwin (AntumDeluge)](https://opengameart.org/user/5625):

- Source: [Mage City Arcanos](https://opengameart.org/node/11192) (CC0)


Contents:

- Corn, squash, & cabbage by [isaiah658](https://opengameart.org/user/36137):
  - Source: [isaiah658's Pixel Pack #1](https://opengameart.org/node/71384) (CC0)
- Everything else by [Jordan Irwin (AntumDeluge)](https://opengameart.org/user/5625). (CC0)
